<?php
// Heading
$_['heading_title']      = 'Employees';

// Text
$_['text_success']       = 'Success: You have modified Employees!';
$_['text_list']          = 'Employee List';
$_['text_add']           = 'Add Employee';
$_['text_edit']          = 'Edit Employee';
$_['text_default']       = 'Default';
$_['text_percent']       = 'Percentage';
$_['text_amount']        = 'Fixed Amount';

// Column
$_['column_name']        = 'Employee Name';
$_['column_sort_order']  = 'Sort Order';
$_['column_action']      = 'Action';

// Entry
$_['entry_name']         = 'Full Name';
$_['entry_email_id']         = 'Email Id';
$_['entry_password']         = 'Password';
$_['entry_contact']         = 'Contact Number';
$_['entry_status']         = 'Status';
$_['entry_city']         = 'Current City';
$_['entry_store']        = 'Stores';
$_['entry_keyword']      = 'SEO URL';
$_['entry_image']        = 'Image';
$_['entry_sort_order']   = 'Sort Order';
$_['entry_type']         = 'Type';

// Help
$_['help_keyword']       = 'Do not use spaces, instead replace spaces with - and make sure the SEO URL is globally unique.';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify Employees!';
$_['error_name']         = 'Employee Name must be between 2 and 64 characters!';
$_['error_keyword']      = 'SEO URL already in use!';
$_['error_product']      = 'Warning: This Employee cannot be deleted as it is currently assigned to %s products!';
